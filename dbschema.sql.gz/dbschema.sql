-- phpMyAdmin SQL Dump
-- version 3.4.11.1deb2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 06, 2013 at 08:51 PM
-- Server version: 5.5.31
-- PHP Version: 5.4.16-1~dotdeb.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sl_site`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_amazon_queue`
--

DROP TABLE IF EXISTS `tbl_amazon_queue`;
CREATE TABLE IF NOT EXISTS `tbl_amazon_queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service` int(11) NOT NULL DEFAULT '0',
  `date` varchar(14) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `service` (`service`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=25729 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_blog`
--

DROP TABLE IF EXISTS `tbl_blog`;
CREATE TABLE IF NOT EXISTS `tbl_blog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `sef_name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(14) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `summary` text COLLATE utf8_unicode_ci NOT NULL,
  `html` text COLLATE utf8_unicode_ci NOT NULL,
  `seo_keywords` text COLLATE utf8_unicode_ci NOT NULL,
  `seo_description` text COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `sef_name` (`sef_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_blog_lng`
--

DROP TABLE IF EXISTS `tbl_blog_lng`;
CREATE TABLE IF NOT EXISTS `tbl_blog_lng` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `object` int(11) NOT NULL DEFAULT '0',
  `lid` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `field` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `object` (`object`,`lid`,`field`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_contents`
--

DROP TABLE IF EXISTS `tbl_contents`;
CREATE TABLE IF NOT EXISTS `tbl_contents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sef_name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `seo_keywords` text COLLATE utf8_unicode_ci NOT NULL,
  `seo_description` text COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `html` text COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `sef_name` (`sef_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_contents_lng`
--

DROP TABLE IF EXISTS `tbl_contents_lng`;
CREATE TABLE IF NOT EXISTS `tbl_contents_lng` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `object` int(11) NOT NULL DEFAULT '0',
  `lid` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `field` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `object` (`object`,`lid`,`field`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_history_log`
--

DROP TABLE IF EXISTS `tbl_history_log`;
CREATE TABLE IF NOT EXISTS `tbl_history_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL,
  `server` int(11) NOT NULL,
  `service` int(11) NOT NULL,
  `date` varchar(14) COLLATE utf8_unicode_ci NOT NULL,
  `error` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `recovery` varchar(14) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user` (`user`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=865 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_ipn_log`
--

DROP TABLE IF EXISTS `tbl_ipn_log`;
CREATE TABLE IF NOT EXISTS `tbl_ipn_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `track_id` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `txn_id` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `ipn_data` text COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(14) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=35 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_menus`
--

DROP TABLE IF EXISTS `tbl_menus`;
CREATE TABLE IF NOT EXISTS `tbl_menus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sef_name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `position` tinyint(4) NOT NULL DEFAULT '99',
  `viewable` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `sef_name` (`sef_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_menus_lng`
--

DROP TABLE IF EXISTS `tbl_menus_lng`;
CREATE TABLE IF NOT EXISTS `tbl_menus_lng` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `object` int(11) NOT NULL DEFAULT '0',
  `lid` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `field` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `object` (`object`,`lid`,`field`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_plans`
--

DROP TABLE IF EXISTS `tbl_plans`;
CREATE TABLE IF NOT EXISTS `tbl_plans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `sef_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `services` smallint(6) DEFAULT NULL,
  `emails` smallint(6) DEFAULT NULL,
  `sms` smallint(6) DEFAULT NULL,
  `mmi` smallint(6) DEFAULT NULL,
  `public` tinyint(1) NOT NULL,
  `position` tinyint(4) NOT NULL,
  `price` double NOT NULL,
  `paypal` text COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_services`
--

DROP TABLE IF EXISTS `tbl_services`;
CREATE TABLE IF NOT EXISTS `tbl_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL DEFAULT '0',
  `name` varchar(128) CHARACTER SET latin1 NOT NULL,
  `port` mediumint(9) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=17 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tips`
--

DROP TABLE IF EXISTS `tbl_tips`;
CREATE TABLE IF NOT EXISTS `tbl_tips` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `sef_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `position` int(11) NOT NULL DEFAULT '99',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `sef_name` (`sef_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tips_lng`
--

DROP TABLE IF EXISTS `tbl_tips_lng`;
CREATE TABLE IF NOT EXISTS `tbl_tips_lng` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `object` int(11) NOT NULL DEFAULT '0',
  `lid` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `field` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `object` (`object`,`lid`,`field`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_plans`
--

DROP TABLE IF EXISTS `tbl_user_plans`;
CREATE TABLE IF NOT EXISTS `tbl_user_plans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL,
  `plan` int(11) NOT NULL,
  `start` varchar(14) COLLATE utf8_unicode_ci NOT NULL,
  `end` varchar(14) COLLATE utf8_unicode_ci NOT NULL,
  `update` varchar(14) COLLATE utf8_unicode_ci NOT NULL,
  `max_services` smallint(6) NOT NULL,
  `services` smallint(6) NOT NULL,
  `max_emails` smallint(6) NOT NULL,
  `emails` smallint(6) NOT NULL,
  `max_sms` smallint(6) DEFAULT NULL,
  `sms` smallint(6) DEFAULT NULL,
  `mmi` smallint(6) NOT NULL,
  `price` float NOT NULL,
  `extra` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `user` (`user`),
  KEY `plan` (`plan`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=142 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_receivers`
--

DROP TABLE IF EXISTS `tbl_user_receivers`;
CREATE TABLE IF NOT EXISTS `tbl_user_receivers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL DEFAULT '0',
  `email` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=145 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_servers`
--

DROP TABLE IF EXISTS `tbl_user_servers`;
CREATE TABLE IF NOT EXISTS `tbl_user_servers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL,
  `register` varchar(14) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `ip` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `updated` varchar(14) COLLATE utf8_unicode_ci NOT NULL,
  `public` tinyint(4) NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user` (`user`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=178 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_services`
--

DROP TABLE IF EXISTS `tbl_user_services`;
CREATE TABLE IF NOT EXISTS `tbl_user_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL,
  `server` int(11) NOT NULL,
  `service` int(11) NOT NULL,
  `mmi` smallint(6) NOT NULL,
  `alert` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `recovery` tinyint(4) NOT NULL DEFAULT '0',
  `register` varchar(14) COLLATE utf8_unicode_ci NOT NULL,
  `updated` varchar(14) COLLATE utf8_unicode_ci NOT NULL,
  `next_update` varchar(14) COLLATE utf8_unicode_ci NOT NULL,
  `extra` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user` (`user`),
  KEY `server` (`server`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=254 ;

-- --------------------------------------------------------

--
-- Table structure for table `wz_etemplates`
--

DROP TABLE IF EXISTS `wz_etemplates`;
CREATE TABLE IF NOT EXISTS `wz_etemplates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `from_name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `from_email` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `subject` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `msg` text COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=17 ;

-- --------------------------------------------------------

--
-- Table structure for table `wz_etemplates_lng`
--

DROP TABLE IF EXISTS `wz_etemplates_lng`;
CREATE TABLE IF NOT EXISTS `wz_etemplates_lng` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `object` int(11) NOT NULL DEFAULT '0',
  `lid` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `field` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `object` (`object`,`lid`,`field`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `wz_settings`
--

DROP TABLE IF EXISTS `wz_settings`;
CREATE TABLE IF NOT EXISTS `wz_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=23 ;

-- --------------------------------------------------------

--
-- Table structure for table `wz_texts`
--

DROP TABLE IF EXISTS `wz_texts`;
CREATE TABLE IF NOT EXISTS `wz_texts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lid` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `hash` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `category` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `text` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lid` (`lid`,`hash`,`category`),
  KEY `hash` (`hash`),
  KEY `lid_2` (`lid`),
  KEY `category` (`category`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=857 ;

-- --------------------------------------------------------

--
-- Table structure for table `wz_users`
--

DROP TABLE IF EXISTS `wz_users`;
CREATE TABLE IF NOT EXISTS `wz_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `language` varchar(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'en',
  `register_date` varchar(14) COLLATE utf8_unicode_ci NOT NULL,
  `last_update` varchar(14) COLLATE utf8_unicode_ci NOT NULL,
  `previous_login` varchar(14) COLLATE utf8_unicode_ci NOT NULL,
  `last_login` varchar(14) COLLATE utf8_unicode_ci NOT NULL,
  `last_seen` varchar(14) COLLATE utf8_unicode_ci NOT NULL,
  `usertype` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'User',
  `plan` int(11) NOT NULL DEFAULT '0',
  `name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `company` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `country` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `billingName` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `billingAddress` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `billingZipCode` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `billingCountry` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `billingVATID` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `billing` int(11) NOT NULL DEFAULT '0',
  `imported` varchar(14) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=156 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
